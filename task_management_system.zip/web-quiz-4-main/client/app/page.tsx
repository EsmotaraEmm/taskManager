import TaskDashboard from "@/components/task-dashboard"

export default function Home() {
  return (
    <main>
      <TaskDashboard />
    </main>
  )
}
